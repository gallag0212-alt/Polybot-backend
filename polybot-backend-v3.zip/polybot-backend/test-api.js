/**
 * test-api.js — Test koneksi ke semua Polymarket APIs
 * Jalankan: node test-api.js
 *
 * Tidak melakukan trading, hanya cek koneksi dan ambil data publik
 */

require('dotenv').config();
const axios = require('axios');

const GAMMA_BASE = 'https://gamma-api.polymarket.com';
const CLOB_BASE  = 'https://clob.polymarket.com';
const DATA_BASE  = 'https://data-api.polymarket.com';

async function testApi() {
  console.log('');
  console.log('╔═══════════════════════════════════════╗');
  console.log('║    PolyBot AI — API Connection Test   ║');
  console.log('╚═══════════════════════════════════════╝');
  console.log('');

  let passed = 0;
  let failed = 0;

  async function check(label, fn) {
    process.stdout.write(`  ${label}... `);
    try {
      const result = await fn();
      console.log(`✅ OK ${result ? '— ' + result : ''}`);
      passed++;
    } catch (e) {
      console.log(`❌ GAGAL — ${e.message}`);
      failed++;
    }
  }

  // ── 1. GAMMA API ─────────────────────────────────────────
  console.log('📊 Gamma API (market data):');

  await check('GET /markets', async () => {
    const { data } = await axios.get(`${GAMMA_BASE}/markets`, {
      params: { active: true, closed: false, limit: 5 }
    });
    const markets = data.markets || data || [];
    return `${markets.length} markets ditemukan`;
  });

  await check('GET /markets (top volume)', async () => {
    const { data } = await axios.get(`${GAMMA_BASE}/markets`, {
      params: { active: true, limit: 1, order: 'volume24hr', ascending: false }
    });
    const markets = data.markets || data || [];
    if (markets[0]) return `Top: "${markets[0].question?.substring(0, 40)}..."`;
  });

  // ── 2. CLOB API ───────────────────────────────────────────
  console.log('');
  console.log('📈 CLOB API (orderbook):');

  await check('GET /time (server time)', async () => {
    const { data } = await axios.get(`${CLOB_BASE}/time`);
    return `Server time: ${data.time}`;
  });

  await check('GET /markets (CLOB)', async () => {
    const { data } = await axios.get(`${CLOB_BASE}/sampling-markets`, {
      params: { next_cursor: '' }
    });
    const count = data?.data?.length || 0;
    return `${count} sampling markets`;
  });

  // ── 3. DATA API ───────────────────────────────────────────
  console.log('');
  console.log('📉 Data API (user data):');

  await check('GET /activity (public)', async () => {
    const { data } = await axios.get(`${DATA_BASE}/activity`, {
      params: { limit: 5 }
    });
    return 'endpoint accessible';
  });

  // ── 4. AUTH CHECK (jika ada credentials) ─────────────────
  const apiKey = process.env.POLY_API_KEY;
  const privKey = process.env.POLY_PRIVATE_KEY;

  console.log('');
  console.log('🔐 Authentication:');

  if (!privKey || privKey.includes('your_wallet')) {
    console.log('  ⚠️  POLY_PRIVATE_KEY belum diisi — skip auth test');
    console.log('      Jalankan: node setup.js untuk generate credentials');
  } else {
    await check('Wallet signer init', async () => {
      const { PolymarketSigner } = require('./src/polymarket-signer');
      const signer = new PolymarketSigner(privKey);
      return `Address: ${signer.getAddress()}`;
    });

    if (apiKey && !apiKey.startsWith('SIM_') && !apiKey.includes('your_api')) {
      await check('L2 headers generation', async () => {
        const { PolymarketSigner } = require('./src/polymarket-signer');
        const signer  = new PolymarketSigner(privKey);
        const headers = await signer.getAuthHeaders('GET', '/orders');
        if (!headers['POLY_API_KEY']) throw new Error('API key missing in headers');
        return 'Headers valid';
      });
    } else {
      console.log('  ⚠️  POLY_API_KEY belum diisi — jalankan node setup.js dulu');
    }
  }

  // ── SUMMARY ───────────────────────────────────────────────
  console.log('');
  console.log('═══════════════════════════════════════════');
  console.log(`  Hasil: ${passed} passed, ${failed} failed`);
  console.log('═══════════════════════════════════════════');

  if (failed === 0) {
    console.log('  ✅ Semua koneksi OK! Bot siap dijalankan.');
  } else {
    console.log('  ⚠️  Ada koneksi yang bermasalah.');
    console.log('     Periksa koneksi internet atau gunakan VPN.');
  }
  console.log('');
}

testApi().catch(console.error);
