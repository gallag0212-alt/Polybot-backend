/**
 * Logger — Simple structured logger
 */

class Logger {
  constructor() {
    this.logs = [];
  }

  _log(level, ...args) {
    const ts  = new Date().toISOString();
    const msg = args.join(' ');
    const entry = `[${ts}] [${level}] ${msg}`;
    console.log(entry);
    this.logs.unshift({ ts, level, msg });
    if (this.logs.length > 1000) this.logs.pop();
  }

  info(...a)  { this._log('INFO',  ...a); }
  warn(...a)  { this._log('WARN',  ...a); }
  error(...a) { this._log('ERROR', ...a); }

  getLogs(limit = 100) {
    return this.logs.slice(0, limit);
  }
}

module.exports = { Logger };
