/**
 * Polymarket WebSocket Client
 * Real-time price & orderbook updates
 * Docs: https://docs.polymarket.com/developers/CLOB/websocket
 */

const WebSocket = require('ws');
const crypto    = require('crypto');

const WSS_URL = 'wss://ws-subscriptions-clob.polymarket.com/ws/';

class PolyWSClient {
  constructor(signer, onPriceUpdate, onTradeUpdate) {
    this.signer          = signer;
    this.onPriceUpdate   = onPriceUpdate || (() => {});
    this.onTradeUpdate   = onTradeUpdate || (() => {});
    this.ws              = null;
    this.subscriptions   = new Set();
    this.reconnectTimer  = null;
    this.connected       = false;
  }

  /**
   * Koneksi ke WebSocket dan subscribe ke market channels
   */
  connect() {
    console.log('[WS] Connecting to Polymarket WebSocket...');

    this.ws = new WebSocket(WSS_URL + 'market');

    this.ws.on('open', () => {
      this.connected = true;
      console.log('[WS] Connected');

      // Re-subscribe semua market yang sudah didaftarkan
      if (this.subscriptions.size > 0) {
        this._sendSubscribe([...this.subscriptions]);
      }
    });

    this.ws.on('message', (raw) => {
      try {
        const messages = JSON.parse(raw);
        const arr = Array.isArray(messages) ? messages : [messages];
        arr.forEach(msg => this._handleMessage(msg));
      } catch (e) {
        console.error('[WS] Parse error:', e.message);
      }
    });

    this.ws.on('close', () => {
      this.connected = false;
      console.warn('[WS] Disconnected — reconnecting in 5s...');
      this.reconnectTimer = setTimeout(() => this.connect(), 5000);
    });

    this.ws.on('error', (err) => {
      console.error('[WS] Error:', err.message);
    });
  }

  /**
   * Subscribe ke price updates untuk satu atau beberapa token
   */
  subscribe(tokenIds) {
    const ids = Array.isArray(tokenIds) ? tokenIds : [tokenIds];
    ids.forEach(id => this.subscriptions.add(id));

    if (this.connected) {
      this._sendSubscribe(ids);
    }
  }

  /**
   * Unsubscribe dari token
   */
  unsubscribe(tokenId) {
    this.subscriptions.delete(tokenId);
    if (this.connected && this.ws) {
      this.ws.send(JSON.stringify({
        type:   'unsubscribe',
        assets_ids: [tokenId],
      }));
    }
  }

  /**
   * Subscribe ke user channel (order fills, dll) — butuh auth
   */
  async subscribeUserChannel() {
    if (!this.signer) return;

    const ts        = Math.floor(Date.now() / 1000).toString();
    const creds     = await this.signer.getOrCreateApiCredentials();
    const message   = ts + 'GET' + '/ws-auth';
    const signature = crypto
      .createHmac('sha256', Buffer.from(creds.secret, 'base64'))
      .update(message)
      .digest('base64');

    const userWs = new WebSocket(WSS_URL + 'user');

    userWs.on('open', () => {
      userWs.send(JSON.stringify({
        auth: {
          apiKey:     creds.apiKey,
          secret:     creds.secret,
          passphrase: creds.passphrase,
        },
        type:       'subscribe',
        channel:    'user',
      }));
    });

    userWs.on('message', (raw) => {
      try {
        const msg = JSON.parse(raw);
        if (msg.event_type === 'trade') {
          this.onTradeUpdate(msg);
        }
      } catch (e) {}
    });

    this.userWs = userWs;
  }

  disconnect() {
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    if (this.ws) this.ws.close();
    if (this.userWs) this.userWs.close();
    this.connected = false;
  }

  // ── PRIVATE ─────────────────────────────────────────────

  _sendSubscribe(tokenIds) {
    this.ws.send(JSON.stringify({
      type:       'subscribe',
      channel:    'prices',
      assets_ids: tokenIds,
    }));
  }

  _handleMessage(msg) {
    // Price update
    if (msg.event_type === 'price_change' || msg.type === 'price_update') {
      this.onPriceUpdate({
        tokenId:    msg.asset_id,
        price:      parseFloat(msg.price || msg.midpoint),
        timestamp:  msg.timestamp || Date.now(),
      });
    }

    // Book update
    if (msg.event_type === 'book') {
      this.onPriceUpdate({
        tokenId:    msg.asset_id,
        price:      parseFloat(msg.midpoint || msg.price),
        bids:       msg.bids,
        asks:       msg.asks,
        timestamp:  Date.now(),
      });
    }
  }
}

module.exports = { PolyWSClient };
