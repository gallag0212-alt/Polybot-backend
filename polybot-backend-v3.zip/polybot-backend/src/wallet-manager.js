/**
 * WalletManager
 * Mengelola semua operasi wallet Polygon untuk Polymarket:
 *  - Cek saldo USDC.e
 *  - Approve token ke Exchange contract
 *  - Setup proxy wallet (Safe) jika belum ada
 *  - Monitor saldo secara berkala
 *
 * Polymarket architecture:
 *   EOA Wallet (kamu)
 *     └── Proxy Wallet / Safe (di-deploy Polymarket)
 *           └── USDC.e + Outcome Tokens
 */

const { ethers } = require('ethers');

// ── POLYGON MAINNET CONFIG ──────────────────────────────────
const POLYGON_RPC  = process.env.POLYGON_RPC || 'https://polygon-rpc.com';
const CHAIN_ID     = 137;

// Contract addresses di Polygon
const CONTRACTS = {
  // USDC.e (Bridged USDC) — token yang dipakai Polymarket
  USDC:     '0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174',
  // Polymarket CTF Exchange contract
  EXCHANGE: '0x4bFb41d5B3570DeFd03C39a9A4D8dE6Bd8B8982E',
  // Conditional Token Framework (outcome tokens)
  CTF:      '0x4D97DCd97eC945f40cF65F87097ACe5EA0476045',
};

// Minimal ABI — hanya fungsi yang kita butuhkan
const ERC20_ABI = [
  'function balanceOf(address owner) view returns (uint256)',
  'function allowance(address owner, address spender) view returns (uint256)',
  'function approve(address spender, uint256 amount) returns (bool)',
  'function decimals() view returns (uint8)',
  'function symbol() view returns (string)',
];

const CTF_ABI = [
  'function setApprovalForAll(address operator, bool approved) returns (bool)',
  'function isApprovedForAll(address account, address operator) view returns (bool)',
];

class WalletManager {
  constructor(privateKey) {
    if (!privateKey) throw new Error('Private key diperlukan');

    this.provider = new ethers.JsonRpcProvider(POLYGON_RPC, {
      chainId: CHAIN_ID,
      name:    'polygon',
    });

    this.signer  = new ethers.Wallet(privateKey, this.provider);
    this.address = this.signer.address;

    // Contract instances
    this.usdc     = new ethers.Contract(CONTRACTS.USDC,     ERC20_ABI, this.signer);
    this.ctf      = new ethers.Contract(CONTRACTS.CTF,      CTF_ABI,   this.signer);
  }

  // ── SALDO ──────────────────────────────────────────────────

  /**
   * Cek saldo USDC.e wallet
   * Return: angka dalam USDC (bukan wei), e.g. 100.50
   */
  async getUSDCBalance(address = null) {
    const addr = address || this.address;
    const raw  = await this.usdc.balanceOf(addr);
    return parseFloat(ethers.formatUnits(raw, 6)); // USDC = 6 decimals
  }

  /**
   * Cek saldo MATIC (untuk gas fee)
   */
  async getMATICBalance() {
    const raw = await this.provider.getBalance(this.address);
    return parseFloat(ethers.formatEther(raw));
  }

  /**
   * Ringkasan saldo lengkap
   */
  async getBalanceSummary() {
    const [usdc, matic] = await Promise.all([
      this.getUSDCBalance(),
      this.getMATICBalance(),
    ]);

    return {
      address:      this.address,
      usdc,
      matic,
      usdcFormatted: `$${usdc.toFixed(2)} USDC.e`,
      maticFormatted: `${matic.toFixed(4)} MATIC`,
      gasOk:         matic >= 0.1, // minimal 0.1 MATIC untuk gas
      hasBalance:    usdc  >= 1,   // minimal $1 untuk trading
    };
  }

  // ── APPROVALS ─────────────────────────────────────────────

  /**
   * Cek apakah Exchange contract sudah di-approve untuk USDC
   */
  async isUSDCApproved() {
    const allowance = await this.usdc.allowance(this.address, CONTRACTS.EXCHANGE);
    // Cukup jika allowance >= $1000 (cukup untuk trading)
    return allowance >= ethers.parseUnits('1000', 6);
  }

  /**
   * Approve Exchange contract untuk menggunakan USDC.e
   * Dipanggil SEKALI saat setup awal
   */
  async approveUSDC() {
    const already = await this.isUSDCApproved();
    if (already) {
      console.log('✅ USDC sudah di-approve sebelumnya');
      return null;
    }

    console.log('📝 Mengirim approve USDC ke Exchange contract...');

    // Approve max amount (uint256 max)
    const MAX_UINT = ethers.MaxUint256;
    const tx = await this.usdc.approve(CONTRACTS.EXCHANGE, MAX_UINT, {
      gasPrice: await this._getGasPrice(),
    });

    console.log(`⏳ Waiting tx: ${tx.hash}`);
    const receipt = await tx.wait();
    console.log(`✅ USDC approved! Block: ${receipt.blockNumber}`);
    return receipt;
  }

  /**
   * Approve Exchange untuk outcome tokens (CTF)
   * Dipanggil SEKALI saat setup awal
   */
  async approveCTF() {
    const already = await this.ctf.isApprovedForAll(this.address, CONTRACTS.EXCHANGE);
    if (already) {
      console.log('✅ CTF sudah di-approve sebelumnya');
      return null;
    }

    console.log('📝 Mengirim approve CTF tokens ke Exchange contract...');

    const tx = await this.ctf.setApprovalForAll(CONTRACTS.EXCHANGE, true, {
      gasPrice: await this._getGasPrice(),
    });

    console.log(`⏳ Waiting tx: ${tx.hash}`);
    const receipt = await tx.wait();
    console.log(`✅ CTF approved! Block: ${receipt.blockNumber}`);
    return receipt;
  }

  /**
   * Jalankan semua setup approval sekaligus
   * Dipanggil dari setup.js
   */
  async runSetupApprovals() {
    console.log('');
    console.log('🔧 Menjalankan wallet setup...');
    console.log(`   Address: ${this.address}`);

    const summary = await this.getBalanceSummary();
    console.log(`   USDC: ${summary.usdcFormatted}`);
    console.log(`   MATIC: ${summary.maticFormatted}`);

    if (!summary.gasOk) {
      throw new Error(`MATIC tidak cukup untuk gas. Minimal 0.1 MATIC, kamu punya ${summary.matic.toFixed(4)}`);
    }

    if (!summary.hasBalance) {
      console.warn('⚠️  USDC saldo rendah — deposit USDC.e ke Polygon dulu sebelum trading');
    }

    await this.approveUSDC();
    await this.approveCTF();

    console.log('');
    console.log('✅ Wallet setup selesai! Siap untuk trading.');
  }

  // ── DEPOSIT GUIDE ─────────────────────────────────────────

  /**
   * Generate deposit address via Polymarket Bridge API
   * Untuk deposit dari chain lain (ETH, Solana, dll)
   */
  async getDepositAddress() {
    const axios = require('axios');
    const { data } = await axios.post('https://bridge.polymarket.com/deposit', {
      address: this.address,
    });
    return data; // array of deposit addresses per chain
  }

  /**
   * Cetak panduan deposit ke console
   */
  async printDepositGuide() {
    const balance = await this.getBalanceSummary();

    console.log('');
    console.log('╔══════════════════════════════════════════╗');
    console.log('║         PANDUAN DEPOSIT USDC             ║');
    console.log('╚══════════════════════════════════════════╝');
    console.log('');
    console.log(`Wallet address kamu: ${this.address}`);
    console.log(`Saldo saat ini: ${balance.usdcFormatted}`);
    console.log('');
    console.log('Cara deposit (pilih salah satu):');
    console.log('');
    console.log('1️⃣  TERMUDAH — Langsung dari exchange:');
    console.log('   - Buka Binance / Coinbase / MEXC');
    console.log('   - Withdraw USDC → pilih network POLYGON');
    console.log(`   - Alamat tujuan: ${this.address}`);
    console.log('   - Biaya gas: ~$0.01, tiba dalam 1-2 menit');
    console.log('');
    console.log('2️⃣  Dari wallet MetaMask (sudah punya USDC di Polygon):');
    console.log('   - Buka MetaMask → pastikan network Polygon');
    console.log('   - Send USDC ke alamat di atas');
    console.log('   - Minimum: $1 USDC');
    console.log('');
    console.log('3️⃣  Bridge dari Ethereum (punya USDC di ETH mainnet):');
    console.log('   - Gunakan https://bridge.polygon.technology');
    console.log('   - Atau https://app.hop.exchange');
    console.log('   - Biaya bridge: ~$2-10 tergantung gas ETH');
    console.log('');
    console.log('⚠️  PENTING: Selalu gunakan network POLYGON, bukan Ethereum!');
    console.log('   Kirim ke network yang salah = dana hilang permanen');
    console.log('');

    // Token USDC.e yang benar
    console.log('📋 Token contract USDC.e di Polygon:');
    console.log(`   ${CONTRACTS.USDC}`);
    console.log('   (Tambahkan manual di MetaMask jika tidak terlihat)');
    console.log('');
  }

  // ── GAS ───────────────────────────────────────────────────

  async _getGasPrice() {
    const feeData = await this.provider.getFeeData();
    // Tambah 20% buffer di atas gas price saat ini
    return feeData.gasPrice * 120n / 100n;
  }

  async estimateGas() {
    const feeData  = await this.provider.getFeeData();
    const gasPrice = parseFloat(ethers.formatUnits(feeData.gasPrice, 'gwei'));
    const txCostUSD = (gasPrice * 100000 * 1e-9 * 0.8).toFixed(4); // approx
    return {
      gasPriceGwei: gasPrice.toFixed(2),
      estimatedTxCostUSD: txCostUSD,
    };
  }

  getAddress() { return this.address; }
}

module.exports = { WalletManager, CONTRACTS };
