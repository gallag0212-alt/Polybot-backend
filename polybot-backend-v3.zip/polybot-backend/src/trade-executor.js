/**
 * Trade Executor
 * Mengelola eksekusi order, monitoring posisi, take-profit & stop-loss
 */

class TradeExecutor {
  constructor(polyClient, moneyManager, state, logger) {
    this.poly   = polyClient;
    this.money  = moneyManager;
    this.state  = state;
    this.logger = logger;
  }

  /**
   * Eksekusi trade berdasarkan sinyal AI
   */
  async execute(signal, amount) {
    if (!signal.outcome) return null;
    if (signal.signal === 'WATCH') return null;
    if (signal.expectedValue <= 0) {
      this.logger.info(`⏭  Skipping ${signal.marketId} — negative EV (${signal.expectedValue})`);
      return null;
    }

    const positionSize = this.money.getPositionSize();
    if (positionSize < 1) {
      this.logger.warn('⚠️  Position size too small, skipping');
      return null;
    }

    const price = signal.outcome === 'YES' ? signal.yesPrice : signal.noPrice;

    this.logger.info(`⚡ Executing: ${signal.signal} ${signal.outcome} on "${signal.question.substring(0,50)}..." @ ${price} | $${positionSize}`);

    try {
      // Place order via Polymarket API
      const order = await this.poly.placeOrder({
        marketId:   signal.marketId,
        outcome:    signal.outcome,
        side:       'BUY',
        price:      price,
        size:       positionSize,
        orderType:  'GTC', // Good Till Cancelled
      });

      // Record open position
      const position = {
        id:           order.id,
        marketId:     signal.marketId,
        question:     signal.question,
        outcome:      signal.outcome,
        entryPrice:   price,
        size:         positionSize,
        signal:       signal.signal,
        aiScore:      signal.aiScore,
        takeProfitAt: price + (price * (this.state.get('takeProfitPct') / 100)),
        stopLossAt:   price - (price * (this.state.get('stopLossPct') / 100)),
        openedAt:     Date.now(),
        status:       'OPEN',
      };

      const positions = this.state.get('openPositions');
      positions.push(position);
      this.state.set('openPositions', positions);

      // Record in trade log
      this.recordTrade({
        ...position,
        type:   'OPEN',
        reason: signal.reason,
      });

      this.logger.info(`✅ Order placed: ${order.id}`);
      return order;

    } catch (err) {
      this.logger.error(`❌ Order failed: ${err.message}`);
      throw err;
    }
  }

  /**
   * Monitor semua posisi terbuka — take profit / stop loss
   */
  async monitorPositions() {
    const positions = this.state.get('openPositions');
    if (positions.length === 0) return;

    for (const pos of positions) {
      try {
        // Fetch current price for this market
        const market = await this.poly.getMarket(pos.marketId);
        const currentPrice = pos.outcome === 'YES'
          ? market.outcomes?.[0]?.price
          : market.outcomes?.[1]?.price;

        if (!currentPrice) continue;

        const pnl = (currentPrice - pos.entryPrice) * pos.size;
        const pnlPct = ((currentPrice - pos.entryPrice) / pos.entryPrice) * 100;

        this.logger.info(`📍 ${pos.question.substring(0,40)}... | ${pos.outcome} | Entry:${pos.entryPrice.toFixed(2)} Now:${currentPrice.toFixed(2)} | PnL: $${pnl.toFixed(2)} (${pnlPct.toFixed(1)}%)`);

        // Check market resolved
        if (market.resolved) {
          await this.closePosition(pos, currentPrice, 'RESOLVED');
          continue;
        }

        // Take profit
        if (currentPrice >= pos.takeProfitAt) {
          this.logger.info(`🎯 Take Profit hit on ${pos.marketId}`);
          await this.closePosition(pos, currentPrice, 'TAKE_PROFIT');
          continue;
        }

        // Stop loss
        if (currentPrice <= pos.stopLossAt) {
          this.logger.warn(`🛑 Stop Loss hit on ${pos.marketId}`);
          await this.closePosition(pos, currentPrice, 'STOP_LOSS');
          continue;
        }

        // Force close near expiry (< 2 days)
        const daysLeft = (new Date(market.endDate) - Date.now()) / (1000 * 60 * 60 * 24);
        if (daysLeft < 2 && currentPrice > pos.entryPrice) {
          this.logger.info(`⏰ Near expiry profit exit on ${pos.marketId}`);
          await this.closePosition(pos, currentPrice, 'EXPIRY_EXIT');
        }

      } catch (err) {
        this.logger.error(`Monitor error on ${pos.marketId}: ${err.message}`);
      }
    }
  }

  /**
   * Tutup posisi dan update P&L
   */
  async closePosition(position, exitPrice, reason) {
    try {
      // Sell position on Polymarket
      await this.poly.placeOrder({
        marketId:  position.marketId,
        outcome:   position.outcome,
        side:      'SELL',
        price:     exitPrice,
        size:      position.size,
        orderType: 'IOC', // Immediate Or Cancel
      });

      const pnl = (exitPrice - position.entryPrice) * position.size;

      // Update money manager
      if (pnl > 0) {
        this.money.recordProfit(pnl);
        this.logger.info(`💰 Profit: +$${pnl.toFixed(2)} (${reason})`);
      } else {
        this.money.recordLoss(Math.abs(pnl));
        this.logger.warn(`📉 Loss: -$${Math.abs(pnl).toFixed(2)} (${reason})`);
      }

      // Remove from open positions
      const positions = this.state.get('openPositions');
      const updated = positions.filter(p => p.id !== position.id);
      this.state.set('openPositions', updated);

      // Log the trade
      this.recordTrade({
        ...position,
        type:      'CLOSE',
        exitPrice,
        pnl,
        closeReason: reason,
        closedAt:  Date.now(),
      });

    } catch (err) {
      this.logger.error(`Close position error: ${err.message}`);
    }
  }

  /**
   * Manual trade dari dashboard
   */
  async manualTrade(marketId, outcome, amount) {
    const market = await this.poly.getMarket(marketId);
    const price  = outcome === 'YES'
      ? market.outcomes?.[0]?.price
      : market.outcomes?.[1]?.price;

    return this.poly.placeOrder({
      marketId, outcome, side: 'BUY',
      price, size: amount,
      orderType: 'GTC',
    });
  }

  recordTrade(data) {
    const trades = this.state.get('trades');
    trades.unshift({ ...data, recordedAt: Date.now() });
    if (trades.length > 500) trades.pop(); // keep last 500
    this.state.set('trades', trades);
  }
}

module.exports = { TradeExecutor };
