/**
 * AI Engine — Analisa market & generate sinyal BUY/SELL/WATCH
 * Menggunakan multi-factor scoring:
 * - Probability momentum
 * - Volume analysis
 * - Spread efficiency
 * - Time decay
 * - Market sentiment
 */

class AIEngine {
  constructor() {
    this.weights = {
      momentum:    0.30,
      volume:      0.20,
      spread:      0.15,
      timeDecay:   0.15,
      sentiment:   0.20,
    };
  }

  /**
   * Analisa array of markets, return signals
   */
  async analyzeMarkets(markets) {
    const signals = [];

    for (const market of markets) {
      try {
        const signal = await this.analyzeMarket(market);
        signals.push(signal);
      } catch (e) {
        // skip invalid market
      }
    }

    return signals;
  }

  /**
   * Analisa satu market, return signal object
   */
  async analyzeMarket(market) {
    const scores = {
      momentum:  this.scoreMomentum(market),
      volume:    this.scoreVolume(market),
      spread:    this.scoreSpread(market),
      timeDecay: this.scoreTimeDecay(market),
      sentiment: this.scoreSentiment(market),
    };

    // Weighted total score (0-100)
    const aiScore = Math.round(
      scores.momentum  * this.weights.momentum  * 100 +
      scores.volume    * this.weights.volume    * 100 +
      scores.spread    * this.weights.spread    * 100 +
      scores.timeDecay * this.weights.timeDecay * 100 +
      scores.sentiment * this.weights.sentiment * 100
    );

    const { signal, outcome, confidence, reason } = this.generateSignal(market, scores, aiScore);
    const expectedValue = this.calcExpectedValue(market, outcome);

    return {
      marketId:      market.id,
      question:      market.question,
      yesPrice:      market.outcomes?.[0]?.price ?? market.bestAsk,
      noPrice:       market.outcomes?.[1]?.price ?? (1 - market.bestAsk),
      volume:        market.volume24h || market.volumeNum,
      daysLeft:      this.daysUntilClose(market.endDate),
      aiScore,
      signal,
      outcome,        // 'YES' or 'NO' — which side to buy
      confidence,
      reason,
      expectedValue,  // EV > 0 = profitable trade
      scores,
    };
  }

  // ── SCORING FACTORS ──────────────────────────────────────

  /**
   * Momentum: apakah probabilitas bergerak searah dalam 24h?
   * Score tinggi = trending kuat
   */
  scoreMomentum(market) {
    const change = market.priceChange24h || 0; // e.g. +0.05 = naik 5%
    const absChange = Math.abs(change);

    if (absChange >= 0.10) return 1.0;   // strong trend
    if (absChange >= 0.05) return 0.75;
    if (absChange >= 0.02) return 0.5;
    return 0.25; // flat
  }

  /**
   * Volume: makin besar volume = makin liquid = lebih aman
   */
  scoreVolume(market) {
    const vol = market.volume24h || market.volumeNum || 0;
    if (vol >= 500000) return 1.0;
    if (vol >= 100000) return 0.85;
    if (vol >= 50000)  return 0.65;
    if (vol >= 10000)  return 0.45;
    return 0.2;
  }

  /**
   * Spread: selisih bid-ask kecil = efisien = lebih mudah profit
   */
  scoreSpread(market) {
    const ask = market.bestAsk || 0.5;
    const bid = market.bestBid || 0.5;
    const spread = Math.abs(ask - bid);

    if (spread <= 0.01) return 1.0;   // very tight
    if (spread <= 0.02) return 0.85;
    if (spread <= 0.04) return 0.65;
    if (spread <= 0.07) return 0.40;
    return 0.15; // wide spread, avoid
  }

  /**
   * Time decay: pasar yang mau tutup dengan probabilitas belum settle
   * - Terlalu jauh: belum punya info cukup
   * - Terlalu dekat (<3 hari): spread melebar
   * - Sweet spot: 7-30 hari
   */
  scoreTimeDecay(market) {
    const days = this.daysUntilClose(market.endDate);
    if (days < 2)   return 0.1;   // terlalu mepet
    if (days < 5)   return 0.5;
    if (days <= 14) return 1.0;   // sweet spot
    if (days <= 30) return 0.85;
    if (days <= 60) return 0.6;
    return 0.3; // terlalu jauh
  }

  /**
   * Sentiment: dari liquidity, trader count, recent activity
   */
  scoreSentiment(market) {
    const traders = market.uniqueTraders || 0;
    const activity = market.lastTradeTime
      ? (Date.now() - new Date(market.lastTradeTime)) / (1000 * 60 * 60)
      : 24;

    let score = 0.5;
    if (traders > 1000) score += 0.3;
    else if (traders > 200) score += 0.2;
    else if (traders > 50) score += 0.1;

    if (activity < 1)  score += 0.2;  // traded in last 1 hour
    else if (activity < 6)  score += 0.1;
    else if (activity > 24) score -= 0.2; // dormant market

    return Math.max(0, Math.min(1, score));
  }

  // ── SIGNAL GENERATION ────────────────────────────────────

  generateSignal(market, scores, aiScore) {
    const yesPrice = market.outcomes?.[0]?.price ?? market.bestAsk ?? 0.5;
    const noPrice  = 1 - yesPrice;
    const change   = market.priceChange24h || 0;

    let signal, outcome, reason;

    if (aiScore < 65) {
      return { signal: 'WATCH', outcome: null, confidence: 0.3, reason: 'AI score terlalu rendah' };
    }

    // Determine which side has edge
    if (yesPrice < 0.35 && change < 0) {
      // YES oversold — potential mean reversion
      signal = 'BUY'; outcome = 'YES';
      reason = `YES oversold (${(yesPrice*100).toFixed(0)}¢), potensi rebound`;
    } else if (noPrice < 0.35 && change > 0) {
      // NO oversold
      signal = 'BUY'; outcome = 'NO';
      reason = `NO oversold (${(noPrice*100).toFixed(0)}¢), potensi rebound`;
    } else if (yesPrice >= 0.55 && yesPrice <= 0.80 && change > 0.02) {
      // YES trending up with momentum
      signal = 'BUY'; outcome = 'YES';
      reason = `YES momentum naik ${(change*100).toFixed(1)}% dalam 24h`;
    } else if (noPrice >= 0.55 && noPrice <= 0.80 && change < -0.02) {
      // NO gaining
      signal = 'BUY'; outcome = 'NO';
      reason = `NO menguat, YES turun ${(Math.abs(change)*100).toFixed(1)}%`;
    } else if (aiScore >= 80) {
      // High score but no clear directional signal — take the stronger side
      if (yesPrice > noPrice) {
        signal = 'BUY'; outcome = 'YES';
        reason = `AI score tinggi (${aiScore}%), YES lebih dominan`;
      } else {
        signal = 'BUY'; outcome = 'NO';
        reason = `AI score tinggi (${aiScore}%), NO lebih dominan`;
      }
    } else {
      signal = 'WATCH'; outcome = null;
      reason = 'Tidak ada edge yang jelas saat ini';
    }

    const confidence = Math.min(0.99, aiScore / 100 + (Math.abs(change) * 0.5));

    return { signal, outcome, confidence, reason };
  }

  /**
   * Expected Value = (prob_win * profit) - (prob_lose * loss)
   * EV > 0 = layak trade
   */
  calcExpectedValue(market, outcome) {
    if (!outcome) return 0;
    const price = outcome === 'YES'
      ? (market.outcomes?.[0]?.price ?? 0.5)
      : (market.outcomes?.[1]?.price ?? 0.5);

    // If resolves YES: profit = (1 - price), loss = price
    const pWin  = outcome === 'YES' ? price : (1 - price); // crude estimate using current price
    const profit = 1 - price;
    const loss   = price;

    return parseFloat(((pWin * profit) - ((1 - pWin) * loss)).toFixed(4));
  }

  daysUntilClose(endDate) {
    if (!endDate) return 30;
    return Math.max(0, (new Date(endDate) - Date.now()) / (1000 * 60 * 60 * 24));
  }
}

module.exports = { AIEngine };
