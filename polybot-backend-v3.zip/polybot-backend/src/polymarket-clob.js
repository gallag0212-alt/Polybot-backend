/**
 * Polymarket Client — Full CLOB API Integration
 * Menggantikan src/polymarket.js dengan implementasi nyata
 *
 * Endpoints:
 *   Gamma API  → https://gamma-api.polymarket.com  (market data, no auth)
 *   CLOB API   → https://clob.polymarket.com       (orderbook + trading, auth required)
 *   Data API   → https://data-api.polymarket.com   (posisi user, trades)
 */

const axios = require('axios');
const { PolymarketSigner } = require('./polymarket-signer');

const CLOB_BASE  = 'https://clob.polymarket.com';
const GAMMA_BASE = 'https://gamma-api.polymarket.com';
const DATA_BASE  = 'https://data-api.polymarket.com';

class PolymarketClient {
  constructor(privateKey) {
    this.isSimulation = !privateKey || privateKey.startsWith('SIM_');
    this.signer       = this.isSimulation ? null : new PolymarketSigner(privateKey);

    this.http = axios.create({ timeout: 15000 });

    // Interceptor: log setiap error
    this.http.interceptors.response.use(
      r => r,
      err => {
        const msg = err.response?.data?.message || err.message;
        console.error(`[PolyClient] API Error: ${msg}`);
        throw new Error(msg);
      }
    );
  }

  // ════════════════════════════════════════════════
  // MARKET DATA (public, no auth)
  // ════════════════════════════════════════════════

  /**
   * Ambil daftar market aktif, diurutkan berdasarkan volume
   * Gunakan Gamma API — paling lengkap untuk metadata market
   */
  async getActiveMarkets({ limit = 50 } = {}) {
    if (this.isSimulation) return this._simMarkets();

    const { data } = await this.http.get(`${GAMMA_BASE}/markets`, {
      params: {
        active:    true,
        closed:    false,
        limit,
        order:     'volume24hr',
        ascending: false,
      }
    });

    // Normalize data struktur
    return (data.markets || data || []).map(m => this._normalizeMarket(m));
  }

  /**
   * Ambil satu market berdasarkan ID
   */
  async getMarket(marketId) {
    if (this.isSimulation) return this._simMarket(marketId);

    const { data } = await this.http.get(`${GAMMA_BASE}/markets/${marketId}`);
    return this._normalizeMarket(data);
  }

  /**
   * Ambil order book untuk token tertentu
   */
  async getOrderBook(tokenId) {
    const { data } = await this.http.get(`${CLOB_BASE}/book`, {
      params: { token_id: tokenId }
    });
    return data; // { bids: [{price, size}], asks: [{price, size}] }
  }

  /**
   * Ambil harga terkini (midpoint)
   */
  async getPrice(tokenId, side = 'BUY') {
    const { data } = await this.http.get(`${CLOB_BASE}/price`, {
      params: { token_id: tokenId, side }
    });
    return parseFloat(data.price);
  }

  /**
   * Ambil spread untuk token
   */
  async getSpread(tokenId) {
    const { data } = await this.http.get(`${CLOB_BASE}/spread`, {
      params: { token_id: tokenId }
    });
    return parseFloat(data.spread);
  }

  /**
   * Ambil history harga untuk analisa momentum
   */
  async getPriceHistory(marketId, resolution = '1h', limit = 24) {
    const { data } = await this.http.get(`${GAMMA_BASE}/markets/${marketId}/prices-history`, {
      params: { resolution, limit }
    });
    return data.history || [];
  }

  /**
   * Ambil posisi user saat ini
   */
  async getPositions(walletAddress) {
    if (this.isSimulation) return [];
    const { data } = await this.http.get(`${DATA_BASE}/positions`, {
      params: { user: walletAddress }
    });
    return data.positions || data || [];
  }

  /**
   * Ambil trades history user
   */
  async getUserTrades(walletAddress, limit = 50) {
    if (this.isSimulation) return [];
    const { data } = await this.http.get(`${DATA_BASE}/activity`, {
      params: { user: walletAddress, limit }
    });
    return data.activity || data || [];
  }

  // ════════════════════════════════════════════════
  // TRADING (requires auth)
  // ════════════════════════════════════════════════

  /**
   * Place order baru
   * @param {object} params
   *   marketId   - ID market dari Gamma API
   *   tokenId    - Token ID dari outcomes (YES atau NO token)
   *   outcome    - 'YES' atau 'NO'
   *   side       - 'BUY' atau 'SELL'
   *   price      - harga limit (0.01 - 0.99)
   *   size       - jumlah shares
   *   orderType  - 'GTC' | 'GTD' | 'FOK' | 'IOC'
   */
  async placeOrder({ marketId, tokenId, outcome, side, price, size, orderType = 'GTC' }) {
    if (this.isSimulation) {
      return this._simOrder({ marketId, outcome, side, price, size });
    }

    if (!this.signer) throw new Error('Signer tidak tersedia');

    // Resolve tokenId jika belum ada
    if (!tokenId) {
      const market = await this.getMarket(marketId);
      tokenId = outcome === 'YES'
        ? market.outcomes[0].tokenId
        : market.outcomes[1].tokenId;
    }

    // Build dan sign order
    const signedOrder = await this.signer.buildAndSignOrder({
      tokenId, side, price, size, orderType
    });

    // Kirim ke CLOB API
    const headers = await this.signer.getAuthHeaders('POST', '/order', JSON.stringify({ order: signedOrder, orderType }));
    const { data } = await this.http.post(`${CLOB_BASE}/order`, {
      order: signedOrder,
      orderType,
    }, { headers });

    return {
      id:       data.orderID || data.id,
      status:   data.status,
      marketId,
      outcome,
      side,
      price,
      size,
      tokenId,
    };
  }

  /**
   * Cancel satu order
   */
  async cancelOrder(orderId) {
    if (this.isSimulation) return { ok: true };
    const headers = await this.signer.getAuthHeaders('DELETE', `/order/${orderId}`);
    const { data } = await this.http.delete(`${CLOB_BASE}/order/${orderId}`, { headers });
    return data;
  }

  /**
   * Cancel semua order di satu market
   */
  async cancelMarketOrders(marketId) {
    if (this.isSimulation) return { ok: true };
    const body    = JSON.stringify({ market: marketId });
    const headers = await this.signer.getAuthHeaders('DELETE', '/orders/market', body);
    const { data } = await this.http.delete(`${CLOB_BASE}/orders/market`, {
      headers, data: { market: marketId }
    });
    return data;
  }

  /**
   * Ambil orders aktif user
   */
  async getOpenOrders() {
    if (this.isSimulation) return [];
    const headers = await this.signer.getAuthHeaders('GET', '/orders');
    const { data } = await this.http.get(`${CLOB_BASE}/orders`, { headers });
    return data || [];
  }

  /**
   * Ambil detail satu order
   */
  async getOrder(orderId) {
    if (this.isSimulation) return null;
    const headers = await this.signer.getAuthHeaders('GET', `/order/${orderId}`);
    const { data } = await this.http.get(`${CLOB_BASE}/order/${orderId}`, { headers });
    return data;
  }

  // ════════════════════════════════════════════════
  // HELPERS
  // ════════════════════════════════════════════════

  /**
   * Normalisasi data market dari berbagai format Gamma API
   * ke format standar yang dipakai bot
   */
  _normalizeMarket(m) {
    const outcomes = m.tokens || m.outcomes || [];
    return {
      id:              m.id || m.condition_id,
      question:        m.question || m.title,
      endDate:         m.endDate || m.end_date_iso,
      resolved:        m.closed || m.archived || false,
      volume24h:       parseFloat(m.volume24hr || m.volume || 0),
      volumeTotal:     parseFloat(m.volumeNum  || m.volume_num || 0),
      priceChange24h:  parseFloat(m.priceChange24hr || 0),
      uniqueTraders:   parseInt(m.uniqueTraders || m.unique_traders || 0),
      lastTradeTime:   m.lastTradeTime,
      bestAsk:         parseFloat(outcomes[0]?.price || 0.5),
      bestBid:         1 - parseFloat(outcomes[0]?.price || 0.5),
      outcomes: outcomes.map((o, i) => ({
        name:    o.outcome || (i === 0 ? 'YES' : 'NO'),
        price:   parseFloat(o.price || 0.5),
        tokenId: o.token_id || o.tokenId || '',
      })),
    };
  }

  getWalletAddress() {
    return this.signer?.getAddress() || null;
  }

  // ════════════════════════════════════════════════
  // SIMULASI MODE
  // ════════════════════════════════════════════════

  _simMarkets() {
    return [
      this._makeSimMarket('sim_001', 'Fed rate cut June 2026?',       0.67, 284500,  0.04,  43),
      this._makeSimMarket('sim_002', 'Bitcoin $120k by July 2026?',   0.41, 512300,  0.03,  72),
      this._makeSimMarket('sim_003', 'Trump EU 25% tariff?',          0.58, 189200, -0.01,  15),
      this._makeSimMarket('sim_004', 'Elon leaves DOGE Aug 2026?',    0.23,  94700, -0.02, 108),
      this._makeSimMarket('sim_005', 'S&P 500 above 5800 April end?', 0.52, 342100,  0.01,  11),
      this._makeSimMarket('sim_006', 'Apple foldable iPhone 2026?',   0.31,  67300,  0.00, 142),
    ];
  }

  _makeSimMarket(id, question, yesPrice, volume, change, daysLeft) {
    return {
      id, question,
      endDate:        new Date(Date.now() + daysLeft * 86400000).toISOString(),
      resolved:       false,
      volume24h:      volume,
      priceChange24h: change,
      uniqueTraders:  Math.floor(volume / 200),
      lastTradeTime:  new Date(Date.now() - 3600000).toISOString(),
      bestAsk:        yesPrice + 0.01,
      bestBid:        yesPrice - 0.01,
      outcomes: [
        { name: 'YES', price: yesPrice,       tokenId: `tok_${id}_yes` },
        { name: 'NO',  price: 1 - yesPrice,   tokenId: `tok_${id}_no`  },
      ],
    };
  }

  _simMarket(id) {
    const found = this._simMarkets().find(m => m.id === id);
    if (!found) throw new Error(`Market ${id} not found`);
    // Simulasi pergerakan harga
    const delta = (Math.random() - 0.5) * 0.02;
    found.outcomes[0].price = Math.max(0.02, Math.min(0.98, found.outcomes[0].price + delta));
    found.outcomes[1].price = 1 - found.outcomes[0].price;
    return found;
  }

  _simOrder({ marketId, outcome, side, price, size }) {
    return {
      id:       `sim_${Date.now()}`,
      status:   'FILLED',
      marketId, outcome, side, price, size,
      filledAt: new Date().toISOString(),
    };
  }
}

module.exports = { PolymarketClient };
