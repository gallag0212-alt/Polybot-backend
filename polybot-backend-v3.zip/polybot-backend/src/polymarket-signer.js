/**
 * PolymarketSigner
 * Menangani L1 (private key) dan L2 (API key) authentication
 * sesuai dokumentasi resmi: https://docs.polymarket.com/developers/CLOB/authentication
 *
 * Flow:
 *   1. L1 Auth  → sign EIP-712 message dengan private key → dapat API credentials
 *   2. L2 Auth  → sign setiap request dengan HMAC-SHA256 menggunakan secret dari L1
 *   3. Order    → setiap order harus di-sign EIP-712 dengan private key
 */

const { ethers }  = require('ethers');
const crypto      = require('crypto');
const axios       = require('axios');

const CLOB_BASE = 'https://clob.polymarket.com';
const CHAIN_ID  = 137; // Polygon mainnet

// EIP-712 Domain untuk ClobAuth
const AUTH_DOMAIN = {
  name:    'ClobAuthDomain',
  version: '1',
  chainId: CHAIN_ID,
};

const AUTH_TYPES = {
  ClobAuth: [
    { name: 'address',   type: 'address' },
    { name: 'timestamp', type: 'string'  },
    { name: 'nonce',     type: 'uint256' },
    { name: 'message',   type: 'string'  },
  ],
};

// EIP-712 Domain untuk Order
const ORDER_DOMAIN = {
  name:              'Polymarket CTF Exchange',
  version:           '1',
  chainId:           CHAIN_ID,
  verifyingContract: '0x4bFb41d5B3570DeFd03C39a9A4D8dE6Bd8B8982E', // Exchange contract
};

const ORDER_TYPES = {
  Order: [
    { name: 'salt',          type: 'uint256' },
    { name: 'maker',         type: 'address' },
    { name: 'signer',        type: 'address' },
    { name: 'taker',         type: 'address' },
    { name: 'tokenId',       type: 'uint256' },
    { name: 'makerAmount',   type: 'uint256' },
    { name: 'takerAmount',   type: 'uint256' },
    { name: 'expiration',    type: 'uint256' },
    { name: 'nonce',         type: 'uint256' },
    { name: 'feeRateBps',    type: 'uint256' },
    { name: 'side',          type: 'uint8'   },
    { name: 'signatureType', type: 'uint8'   },
  ],
};

class PolymarketSigner {
  constructor(privateKey) {
    if (!privateKey) throw new Error('Private key diperlukan untuk signing');
    this.wallet  = new ethers.Wallet(privateKey);
    this.address = this.wallet.address;
    this._creds  = null; // L2 credentials (di-cache)
  }

  // ── L1: DERIVE API CREDENTIALS ───────────────────────────

  /**
   * Dapatkan atau buat L2 API credentials menggunakan L1 (private key)
   * Dipanggil sekali, lalu cache hasilnya
   */
  async getOrCreateApiCredentials() {
    if (this._creds) return this._creds;

    // Dapatkan server timestamp
    const { data: tsData } = await axios.get(`${CLOB_BASE}/time`);
    const timestamp = String(tsData.time);
    const nonce     = 0;

    // Sign EIP-712 message
    const value = {
      address:   this.address,
      timestamp,
      nonce,
      message: 'This message attests that I control the given wallet',
    };

    const signature = await this.wallet.signTypedData(AUTH_DOMAIN, AUTH_TYPES, value);

    // Request API key dari Polymarket
    const headers = this._buildL1Headers(timestamp, nonce, signature);
    const { data } = await axios.get(`${CLOB_BASE}/auth/api-key`, { headers });

    this._creds = {
      apiKey:     data.apiKey,
      secret:     data.secret,
      passphrase: data.passphrase,
    };

    return this._creds;
  }

  // ── L2: REQUEST HEADERS ──────────────────────────────────

  /**
   * Build headers L2 untuk setiap authenticated request
   * Menggunakan HMAC-SHA256
   */
  async getAuthHeaders(method = 'GET', path = '', body = '') {
    const creds = await this.getOrCreateApiCredentials();
    const ts    = Math.floor(Date.now() / 1000).toString();

    // HMAC signature: timestamp + method + path + body
    const message   = ts + method.toUpperCase() + path + (body || '');
    const signature = crypto
      .createHmac('sha256', Buffer.from(creds.secret, 'base64'))
      .update(message)
      .digest('base64');

    return {
      'POLY_ADDRESS':    this.address,
      'POLY_SIGNATURE':  signature,
      'POLY_TIMESTAMP':  ts,
      'POLY_API_KEY':    creds.apiKey,
      'POLY_PASSPHRASE': creds.passphrase,
      'Content-Type':    'application/json',
    };
  }

  // ── ORDER SIGNING ─────────────────────────────────────────

  /**
   * Build dan sign order dengan EIP-712
   * Ini diperlukan untuk setiap order baru
   */
  async buildAndSignOrder({ tokenId, side, price, size, orderType = 'GTC', expiration = 0 }) {
    const SIDE_BUY  = 0;
    const SIDE_SELL = 1;
    const SIG_TYPE  = 0; // EOA signature

    // Konversi ke unit yang benar (Polymarket pakai 6 decimal USDC)
    const priceInt = Math.round(price * 1e6);
    const sizeInt  = Math.round(size  * 1e6);

    // makerAmount & takerAmount tergantung side
    // BUY:  maker = USDC (cost), taker = shares
    // SELL: maker = shares, taker = USDC
    const makerAmount = side === 'BUY'
      ? Math.round(size * price * 1e6)   // USDC spent
      : Math.round(size * 1e6);           // shares sold

    const takerAmount = side === 'BUY'
      ? Math.round(size * 1e6)            // shares received
      : Math.round(size * price * 1e6);   // USDC received

    const orderStruct = {
      salt:          Math.floor(Math.random() * 1e15),
      maker:         this.address,
      signer:        this.address,
      taker:         '0x0000000000000000000000000000000000000000',
      tokenId:       BigInt(tokenId),
      makerAmount:   BigInt(makerAmount),
      takerAmount:   BigInt(takerAmount),
      expiration:    BigInt(expiration),
      nonce:         BigInt(0),
      feeRateBps:    BigInt(0),
      side:          side === 'BUY' ? SIDE_BUY : SIDE_SELL,
      signatureType: SIG_TYPE,
    };

    const signature = await this.wallet.signTypedData(ORDER_DOMAIN, ORDER_TYPES, orderStruct);

    return {
      salt:          orderStruct.salt.toString(),
      maker:         this.address,
      signer:        this.address,
      taker:         orderStruct.taker,
      tokenId:       tokenId.toString(),
      makerAmount:   makerAmount.toString(),
      takerAmount:   takerAmount.toString(),
      expiration:    expiration.toString(),
      nonce:         '0',
      feeRateBps:    '0',
      side:          side === 'BUY' ? '0' : '1',
      signatureType: '0',
      signature,
      // Order metadata
      orderType,    // GTC, GTD, FOK, IOC
    };
  }

  // ── HELPERS ───────────────────────────────────────────────

  _buildL1Headers(timestamp, nonce, signature) {
    return {
      'POLY_ADDRESS':   this.address,
      'POLY_SIGNATURE': signature,
      'POLY_TIMESTAMP': timestamp,
      'POLY_NONCE':     String(nonce),
      'Content-Type':   'application/json',
    };
  }

  getAddress() { return this.address; }
}

module.exports = { PolymarketSigner };
