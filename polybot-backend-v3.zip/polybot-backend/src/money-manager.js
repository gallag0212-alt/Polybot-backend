/**
 * Money Manager — Implementasi aturan 50% profit
 *
 * ATURAN:
 * - Dana yang boleh digunakan untuk trade = 50% dari AKUMULASI PROFIT
 * - Modal awal TIDAK boleh disentuh
 * - Semakin banyak profit, semakin besar dana yang bisa ditradingkan
 * - Jika belum ada profit, tidak ada trade
 */

class MoneyManager {
  constructor(state) {
    this.state = state;
  }

  /**
   * Hitung jumlah dana yang tersedia untuk trade sekarang
   * = 50% dari total accumulated profit
   */
  getAllocatedAmount() {
    const profit = this.state.get('totalProfit');
    if (profit <= 0) return 0;

    const allocated = profit * 0.50;

    // Pastikan tidak melebihi saldo aktual
    const balance = this.state.get('balance');
    const initialCapital = this.state.get('initialCapital');
    const maxSafe = balance - initialCapital; // hanya gunakan dari profit portion

    return Math.min(allocated, Math.max(0, maxSafe));
  }

  /**
   * Hitung ukuran posisi untuk satu trade
   * Bagi dana tersedia ke max concurrent trades
   */
  getPositionSize() {
    const available    = this.getAllocatedAmount();
    const openCount    = this.state.get('openPositions').length;
    const maxConcurrent = this.state.get('maxConcurrentTrades') || 3;

    if (available <= 0) return 0;

    // Remaining slots
    const slots = Math.max(1, maxConcurrent - openCount);

    // Split available funds evenly across slots
    const size = available / slots;

    // Min trade size on Polymarket is $1
    return Math.max(1, parseFloat(size.toFixed(2)));
  }

  /**
   * Setelah trade close dengan profit, update state
   */
  recordProfit(amount) {
    const current = this.state.get('totalProfit');
    this.state.set('totalProfit', current + amount);
    this.state.set('balance', this.state.get('balance') + amount);

    // Update PNL history
    const history = this.state.get('pnlHistory');
    history.push({
      ts:     Date.now(),
      profit: this.state.get('totalProfit'),
      delta:  amount,
    });
    this.state.set('pnlHistory', history);

    return this.getAllocatedAmount();
  }

  /**
   * Setelah trade close dengan loss
   */
  recordLoss(amount) {
    const current = this.state.get('totalProfit');
    const newProfit = Math.max(0, current - amount); // profit tidak bisa negatif dari modal
    this.state.set('totalProfit', newProfit);
    this.state.set('balance', Math.max(
      this.state.get('initialCapital'), // jangan sampai di bawah modal awal
      this.state.get('balance') - amount
    ));

    const history = this.state.get('pnlHistory');
    history.push({
      ts:     Date.now(),
      profit: newProfit,
      delta:  -amount,
    });
    this.state.set('pnlHistory', history);
  }

  /**
   * Summary untuk dashboard
   */
  getSummary() {
    const profit     = this.state.get('totalProfit');
    const balance    = this.state.get('balance');
    const initial    = this.state.get('initialCapital');

    return {
      initialCapital: initial,
      currentBalance: balance,
      totalProfit:    profit,
      profitPct:      initial > 0 ? ((profit / initial) * 100).toFixed(2) + '%' : '0%',
      tradeable:      this.getAllocatedAmount(),   // 50% of profit
      locked:         profit * 0.50,               // other 50% stays
      positionSize:   this.getPositionSize(),
    };
  }
}

module.exports = { MoneyManager };
