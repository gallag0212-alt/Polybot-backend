/**
 * State Manager — Menyimpan & membaca state bot
 * Persist ke file JSON (bisa diganti Redis/DB untuk production)
 */

const fs   = require('fs');
const path = require('path');

const STATE_FILE = path.join(__dirname, '..', 'data', 'state.json');

const DEFAULTS = {
  botActive:           false,
  initialCapital:      100,
  balance:             100,
  totalProfit:         0,
  openPositions:       [],
  trades:              [],
  pnlHistory:          [],

  // Settings
  minAiScore:          75,
  maxTradesPerCycle:   2,
  maxConcurrentTrades: 3,
  takeProfitPct:       25,
  stopLossPct:         15,
  strategy:            'momentum',
};

class StateManager {
  constructor() {
    this._state = { ...DEFAULTS };
    this._load();
  }

  get(key) {
    return this._state[key];
  }

  set(key, value) {
    this._state[key] = value;
    this._save();
  }

  getSettings() {
    return {
      minAiScore:          this._state.minAiScore,
      maxTradesPerCycle:   this._state.maxTradesPerCycle,
      maxConcurrentTrades: this._state.maxConcurrentTrades,
      takeProfitPct:       this._state.takeProfitPct,
      stopLossPct:         this._state.stopLossPct,
      strategy:            this._state.strategy,
    };
  }

  getWinRate() {
    const trades = this._state.trades.filter(t => t.type === 'CLOSE');
    if (trades.length === 0) return 0;
    const wins = trades.filter(t => t.pnl > 0).length;
    return parseFloat(((wins / trades.length) * 100).toFixed(1));
  }

  reset() {
    this._state = { ...DEFAULTS };
    this._save();
  }

  _load() {
    try {
      if (fs.existsSync(STATE_FILE)) {
        const raw = fs.readFileSync(STATE_FILE, 'utf8');
        this._state = { ...DEFAULTS, ...JSON.parse(raw) };
      }
    } catch (e) {
      console.warn('Could not load state file, using defaults');
    }
  }

  _save() {
    try {
      const dir = path.dirname(STATE_FILE);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(STATE_FILE, JSON.stringify(this._state, null, 2));
    } catch (e) {
      console.warn('Could not save state:', e.message);
    }
  }
}

module.exports = { StateManager };
