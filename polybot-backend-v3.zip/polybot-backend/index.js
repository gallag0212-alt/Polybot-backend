/**
 * PolyBot AI — Backend Server (Node.js)
 * Auto Trading Bot for Polymarket
 * Deploy: Railway.app / Render / VPS
 */

require('dotenv').config();

const express = require('express');
const cors    = require('cors');
const cron    = require('node-cron');

const { PolymarketClient } = require('./src/polymarket-clob');
const { AIEngine }         = require('./src/ai-engine');
const { MoneyManager }     = require('./src/money-manager');
const { TradeExecutor }    = require('./src/trade-executor');
const { WalletManager }    = require('./src/wallet-manager');
const { Logger }           = require('./src/logger');
const { StateManager }     = require('./src/state');

const app = express();
app.use(cors());
app.use(express.json());

// ─── INIT ─────────────────────────────────────────────────────
const state  = new StateManager();
const logger = new Logger();
const poly   = new PolymarketClient(process.env.POLY_PRIVATE_KEY);
const ai     = new AIEngine();
const money  = new MoneyManager(state);
const trader = new TradeExecutor(poly, money, state, logger);

if (process.env.INITIAL_CAPITAL) {
  const ic = parseFloat(process.env.INITIAL_CAPITAL);
  state.set('initialCapital', ic);
  if (state.get('balance') <= 1) state.set('balance', ic);
}

// ─── BOT LOOP ─────────────────────────────────────────────────
async function botLoop() {
  if (!state.get('botActive')) return;
  logger.info('Scanning markets...');
  try {
    const markets = await poly.getActiveMarkets({ limit: 50 });
    const signals = await ai.analyzeMarkets(markets);
    const strong  = signals.filter(s =>
      s.aiScore >= state.get('minAiScore') &&
      s.signal !== 'WATCH' &&
      s.confidence >= 0.7 &&
      s.expectedValue > 0
    );
    logger.info(`${strong.length} sinyal kuat dari ${markets.length} markets`);
    for (const sig of strong.slice(0, state.get('maxTradesPerCycle'))) {
      const alloc = money.getAllocatedAmount();
      if (alloc < 1) { logger.warn('Dana tidak cukup (50% profit rule)'); break; }
      await trader.execute(sig, alloc);
      await sleep(2000);
    }
    await trader.monitorPositions();
    await syncBalance();
  } catch (err) {
    logger.error('Bot loop error:', err.message);
  }
}

async function syncBalance() {
  if (poly.isSimulation || !process.env.POLY_PRIVATE_KEY) return;
  try {
    const wm  = new WalletManager(process.env.POLY_PRIVATE_KEY);
    const bal = await wm.getUSDCBalance();
    state.set('balance', bal);
    const ic = state.get('initialCapital');
    if (bal > ic) state.set('totalProfit', parseFloat((bal - ic).toFixed(2)));
  } catch (_) {}
}

// ─── SCHEDULERS ──────────────────────────────────────────────
cron.schedule('*/5 * * * *',  botLoop);
cron.schedule('* * * * *',    () => { if (state.get('botActive')) trader.monitorPositions(); });
cron.schedule('*/10 * * * *', syncBalance);

// ─── API ENDPOINTS ────────────────────────────────────────────
app.get('/status', (req, res) => res.json({
  botActive:      state.get('botActive'),
  isSimulation:   poly.isSimulation,
  profit:         state.get('totalProfit'),
  balance:        state.get('balance'),
  initialCapital: state.get('initialCapital'),
  tradeable:      money.getAllocatedAmount(),
  moneySummary:   money.getSummary(),
  winRate:        state.getWinRate(),
  totalTrades:    state.get('trades').length,
  openPositions:  state.get('openPositions').length,
  uptime:         Math.floor(process.uptime()),
  settings:       state.getSettings(),
}));

app.get('/trades',    (req, res) => res.json(state.get('trades').slice(-50)));
app.get('/positions', (req, res) => res.json(state.get('openPositions')));
app.get('/pnl',       (req, res) => res.json(state.get('pnlHistory')));
app.get('/logs',      (req, res) => res.json(logger.getLogs(100)));

app.get('/signals', async (req, res) => {
  try {
    const markets = await poly.getActiveMarkets({ limit: 30 });
    const signals = await ai.analyzeMarkets(markets);
    res.json(signals.sort((a, b) => b.aiScore - a.aiScore));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/wallet', async (req, res) => {
  if (poly.isSimulation) return res.json({ simulation: true, balance: state.get('balance') });
  try {
    const wm = new WalletManager(process.env.POLY_PRIVATE_KEY);
    res.json({ ...(await wm.getBalanceSummary()), ...(await wm.estimateGas()) });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/bot/start', (req, res) => {
  state.set('botActive', true);
  logger.info('Bot started');
  botLoop();
  res.json({ ok: true, message: 'Bot started' });
});

app.post('/bot/stop', (req, res) => {
  state.set('botActive', false);
  logger.info('Bot stopped');
  res.json({ ok: true, message: 'Bot stopped' });
});

app.post('/trade/manual', async (req, res) => {
  try {
    const result = await trader.manualTrade(req.body.marketId, req.body.outcome, req.body.amount);
    res.json({ ok: true, result });
  } catch (e) { res.status(400).json({ ok: false, error: e.message }); }
});

app.post('/settings', (req, res) => {
  ['minAiScore','maxTradesPerCycle','stopLossPct','takeProfitPct','strategy'].forEach(k => {
    if (req.body[k] !== undefined) state.set(k, req.body[k]);
  });
  res.json({ ok: true, settings: state.getSettings() });
});

app.post('/bot/reset', (req, res) => { state.reset(); res.json({ ok: true }); });
app.get('/health',     (req, res) => res.json({ status: 'ok', ts: Date.now(), mode: poly.isSimulation ? 'simulation' : 'live' }));

// ─── START ────────────────────────────────────────────────────
const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  logger.info(`PolyBot backend running on port ${PORT}`);
  logger.info(`Mode: ${poly.isSimulation ? 'SIMULASI' : 'LIVE TRADING'}`);
  if (process.env.AUTO_START === 'true') {
    state.set('botActive', true);
    setTimeout(botLoop, 3000);
  }
});

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
module.exports = app;
