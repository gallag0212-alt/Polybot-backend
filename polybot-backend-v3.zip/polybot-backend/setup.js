/**
 * setup.js — Jalankan SEKALI untuk setup lengkap
 *
 * Yang dilakukan:
 *   Step 1: Validasi private key & cek saldo wallet
 *   Step 2: Approve USDC + CTF tokens ke Exchange contract (on-chain)
 *   Step 3: Generate L2 API credentials dari Polymarket
 *   Step 4: Simpan semua config ke .credentials.json
 *
 * Cara pakai:
 *   node setup.js
 */

require('dotenv').config();
const fs  = require('fs');
const { PolymarketSigner } = require('./src/polymarket-signer');
const { WalletManager }    = require('./src/wallet-manager');

function printStep(n, label) {
  console.log('');
  console.log(`──────────────────────────────────────────`);
  console.log(`  Step ${n}: ${label}`);
  console.log(`──────────────────────────────────────────`);
}

async function setup() {
  console.log('');
  console.log('╔═════════════════════════════════════════╗');
  console.log('║      PolyBot AI — Full Setup Wizard     ║');
  console.log('╚═════════════════════════════════════════╝');

  const privateKey = process.env.POLY_PRIVATE_KEY;
  if (!privateKey || privateKey.includes('your_wallet') || privateKey.length < 60) {
    console.error('\n❌ POLY_PRIVATE_KEY belum diisi di file .env');
    console.error('   MetaMask → Settings → Security → Reveal Secret Private Key');
    console.error('   ⚠️  Gunakan wallet BARU khusus bot, bukan wallet utama!');
    process.exit(1);
  }

  // ── Step 1: Cek wallet ───────────────────────────────────
  printStep(1, 'Validasi Wallet & Saldo');

  const wallet = new WalletManager(privateKey);
  console.log(`📍 Wallet address: ${wallet.getAddress()}`);

  let balance;
  try {
    balance = await wallet.getBalanceSummary();
    console.log(`💰 USDC.e : ${balance.usdcFormatted}`);
    console.log(`⛽ MATIC  : ${balance.maticFormatted}`);

    if (!balance.gasOk) {
      console.error('\n❌ MATIC tidak cukup untuk gas! Minimal 0.1 MATIC');
      console.error('   Beli MATIC di exchange lalu withdraw ke Polygon network');
      process.exit(1);
    }
    if (!balance.hasBalance) {
      console.warn('\n⚠️  USDC.e kosong — setup lanjut, deposit bisa dilakukan nanti');
      await wallet.printDepositGuide();
    } else {
      console.log('✅ Saldo cukup untuk trading');
    }
  } catch (err) {
    console.error(`❌ Gagal cek saldo: ${err.message}`);
    process.exit(1);
  }

  // ── Step 2: On-chain approvals ───────────────────────────
  printStep(2, 'On-chain Token Approvals (2 transaksi ~$0.01 gas)');
  try {
    await wallet.runSetupApprovals();
  } catch (err) {
    console.error(`❌ Approval gagal: ${err.message}`);
    process.exit(1);
  }

  // ── Step 3: API Credentials ──────────────────────────────
  printStep(3, 'Generate Polymarket API Credentials');

  let creds;
  try {
    const signer = new PolymarketSigner(privateKey);
    console.log('📡 Menghubungi Polymarket server...');
    creds = await signer.getOrCreateApiCredentials();
    console.log('✅ Credentials OK!');
    console.log(`   API Key    : ${creds.apiKey}`);
    console.log(`   Secret     : ${creds.secret.substring(0, 8)}...`);
    console.log(`   Passphrase : ${creds.passphrase.substring(0, 6)}...`);
  } catch (err) {
    console.error(`❌ Gagal: ${err.message}`);
    console.error('   Pastikan wallet pernah login di app.polymarket.com');
    process.exit(1);
  }

  // ── Step 4: Simpan ───────────────────────────────────────
  printStep(4, 'Simpan Konfigurasi');

  fs.writeFileSync('.credentials.json', JSON.stringify({
    walletAddress:  wallet.getAddress(),
    apiKey:         creds.apiKey,
    secret:         creds.secret,
    passphrase:     creds.passphrase,
    initialBalance: balance.usdc,
    generatedAt:    new Date().toISOString(),
    network:        'polygon-mainnet',
    chainId:        137,
  }, null, 2));

  let envText = fs.existsSync('.env')
    ? fs.readFileSync('.env', 'utf8')
    : fs.readFileSync('.env.example', 'utf8');

  const updates = {
    POLY_API_KEY:        creds.apiKey,
    POLY_WALLET_ADDRESS: wallet.getAddress(),
    INITIAL_CAPITAL:     Math.floor(balance.usdc).toString(),
    AUTO_START:          'false',
  };
  Object.entries(updates).forEach(([k, v]) => {
    const re = new RegExp(`^${k}=.*`, 'm');
    envText = re.test(envText) ? envText.replace(re, `${k}=${v}`) : envText + `\n${k}=${v}`;
  });
  fs.writeFileSync('.env', envText);

  console.log('💾 .credentials.json tersimpan');
  console.log('✅ .env diupdate');

  // ── Done ─────────────────────────────────────────────────
  console.log('');
  console.log('╔═════════════════════════════════════════╗');
  console.log('║          ✅  SETUP SELESAI!             ║');
  console.log('╚═════════════════════════════════════════╝');
  console.log('');
  console.log(`  Wallet  : ${wallet.getAddress()}`);
  console.log(`  Saldo   : ${balance.usdcFormatted}`);
  console.log(`  API Key : ${creds.apiKey.substring(0, 18)}...`);
  console.log('');
  console.log('  Langkah selanjutnya:');
  console.log('  1.  node test-api.js   → verifikasi koneksi');
  console.log('  2.  npm start          → jalankan bot');
  console.log('  3.  POST /bot/start    → aktifkan bot dari dashboard HP');
  console.log('');
  console.log('  ⚠️  JANGAN commit .env & .credentials.json ke GitHub!');
  console.log('');
}

setup().catch(err => {
  console.error('\n❌ Setup error:', err.message);
  process.exit(1);
});
