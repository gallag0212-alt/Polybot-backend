# 🤖 PolyBot AI — Backend Server

Auto trading bot untuk Polymarket berbasis Node.js.

## Struktur Project

```
polybot-backend/
├── index.js                 ← Server utama + scheduler
├── package.json
├── .env.example             ← Template environment variables
├── data/
│   └── state.json           ← State bot (auto-generated)
└── src/
    ├── ai-engine.js         ← AI scoring & signal generation
    ├── money-manager.js     ← Aturan 50% profit
    ├── trade-executor.js    ← Eksekusi order + monitoring
    ├── polymarket.js        ← Polymarket API client
    ├── polymarket-signer.js ← Wallet signing (step berikutnya)
    ├── state.js             ← State management
    └── logger.js            ← Logging
```

## REST API Endpoints

| Method | Endpoint         | Fungsi                        |
|--------|-----------------|-------------------------------|
| GET    | /status          | Status bot & statistik        |
| GET    | /trades          | Riwayat trade                 |
| GET    | /positions       | Posisi terbuka                |
| GET    | /signals         | Sinyal AI terkini             |
| GET    | /pnl             | History P&L                   |
| POST   | /bot/start       | Mulai bot                     |
| POST   | /bot/stop        | Hentikan bot                  |
| POST   | /trade/manual    | Manual trade                  |
| POST   | /settings        | Update konfigurasi            |
| GET    | /health          | Health check                  |

## Deploy ke Railway (Gratis)

### Langkah 1 — Siapkan GitHub repo
```bash
git init
git add .
git commit -m "Initial polybot backend"
git remote add origin https://github.com/USERNAME/polybot-backend.git
git push -u origin main
```

### Langkah 2 — Deploy ke Railway
1. Buka https://railway.app
2. Klik **New Project** → **Deploy from GitHub repo**
3. Pilih repo `polybot-backend`
4. Railway otomatis detect Node.js & install dependencies

### Langkah 3 — Set Environment Variables
Di Railway dashboard → Variables, tambahkan:
```
POLY_API_KEY       = (dari Polymarket)
POLY_PRIVATE_KEY   = (private key wallet)
POLY_WALLET_ADDRESS= (alamat wallet)
AUTO_START         = false
INITIAL_CAPITAL    = 100
PORT               = 3001
```

### Langkah 4 — Get Public URL
Railway memberi URL publik seperti:
`https://polybot-production.up.railway.app`

Masukkan URL ini ke dashboard HP sebagai API endpoint.

## Mode Simulasi vs Nyata

Bot otomatis masuk **mode simulasi** jika:
- `POLY_API_KEY` dimulai dengan `SIM_`
- atau tidak ada API key

Untuk trading nyata, isi API key & private key yang valid.

## Money Management Rule

Dana trade = 50% dari akumulasi profit
- Modal awal $100 tidak disentuh
- Baru bisa trade setelah ada profit
- Semakin besar profit, semakin besar dana tersedia

Contoh:
- Modal: $100, Profit: $50 → Dana trade: $25 (50% dari $50)
- Modal: $100, Profit: $100 → Dana trade: $50

## ⚠️ Disclaimer

Bot ini untuk tujuan edukasi. Trading prediction market
mengandung risiko. Gunakan hanya dana yang siap hilang.
